const element = document.querySelector('img[alt="Google"]')

element.outerHTML = `
    <h1>Mahdi Search</h1>
`
